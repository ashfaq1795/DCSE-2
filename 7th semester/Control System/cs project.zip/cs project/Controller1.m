A=[2, 3; 0, 5];
B=[1; 2];
C=[1, 0; 0, 1];
D=[0; 0];
%method1
step(A,B,C,D)

%method2
x1=eig(A);
disp('Eigen values are:')
x1

%method3
[nu, de]=ss2tf(A,B,C,D);
disp('Poles are:')
x2=roots(de);
x2

%method4 RH Method 
%method5 Root Locus


%check controlability
P=ctrb(A,B);
R=rank(P);
disp('Rank is:')
R


%Design Controlaibility
Desired_Eval=[-3 -5];
K=place(A,B,Desired_Eval);
disp('Vlues of K are:')
K