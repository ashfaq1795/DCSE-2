clear all 
clc
A = [0 1; -3 1]
B = [1 0; 0 1]
C = [1 0]
D = [0 0]

%chek stability
%method1
figure

step(A,B,C,D)


%method2
disp('The eignvalues of matrix A are')
eigen_values = eig(A)

%method3
[nu1 , de1] = ss2tf(A,B,C,D,1);
disp('The Roots are:')
Roots_for_Input_1 = roots(de1)
[nu2 , de2] = ss2tf(A,B,C,D,2);
disp('The Roots are:')
Roots_for_Input_2=roots(de2)

%method4 RH Method 

%method5 Root Locus
Sys1=tf(nu1,de1)
Sys2=tf(nu2,de2)
figure
rlocus(Sys1)
title('Root Locus Input 1')
figure
rlocus(Sys2)
title('Root Locus Input 2')



%Controlability Test
P = ctrb(A,B)
rank_of_ctrbl_matrix = rank(P);
disp('The rank of controllabilty matrix')
rank_of_ctrbl_matrix

size_of_matrix_A = size(A,1)

%Observability Test
% 1- Matrix C is not identity matrix
Q = obsv(A,C)
rank_of_obsv = rank(Q);
disp('The rank of observability matrix ');
rank_of_obsv


desrired_eignvalues1 = [-30 -50];
L = place (A',C',desrired_eignvalues1)';
L


%Design Controlaibility
desrired_eignvalues2 = [-3 -5];
K = place (A,B,desrired_eignvalues2);    %for K1, K2, K3
K

B_upd = [B L];
B_upd

