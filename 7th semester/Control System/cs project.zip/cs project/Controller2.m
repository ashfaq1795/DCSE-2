clear 
clc
A = [2 3; 0 5];
B = [1;2];
C = [1 0];
D = [0];
%chek stability
%method1
step(A,B,C,D)

%method2
disp('The eignvalues of matrix A are')
eigen_values = eig(A)

%method3
[nu , de] = ss2tf(A,B,C,D);
roots(de)

%method4 RH Method 
%method5 Root Locus




%check controlability
P = ctrb(A,B);
rank_of_ctrbl_matrix = rank(P);
disp('The rank of controliabilty')
rank_of_ctrbl_matrix

%check observability
Q = obsv(A , C)
rank_of_obsv = rank(Q);
disp('The rank of observebility');
rank_of_obsv


desrired_eignvalues1 = [-10 -20];
L = place (A',C',desrired_eignvalues1)';
L


%Design Controlaibility
desrired_eignvalues2 = [-3 -5];
K = place (A,B,desrired_eignvalues2);    %for K1, K2, K3
K

